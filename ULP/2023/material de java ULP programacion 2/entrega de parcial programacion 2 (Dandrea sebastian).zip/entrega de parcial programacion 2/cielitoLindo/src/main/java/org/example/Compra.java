package org.example;

public interface Compra {

    public void compraTotal();
}
